/* PushRegister.js
   Note: This code is written for Expo-managed workflow. Install expo-notifications and follow docs.
   It requests permissions, gets Expo push token and sends to backend endpoint /users/me/push-token
*/
import * as Notifications from 'expo-notifications';
import * as Permissions from 'expo-permissions';
import AsyncStorage from '@react-native-async-storage/async-storage';

export async function registerForPushNotificationsAsync() {
  try {
    const { status: existingStatus } = await Permissions.getAsync(Permissions.NOTIFICATIONS);
    let finalStatus = existingStatus;
    if (existingStatus !== 'granted') {
      const { status } = await Permissions.askAsync(Permissions.NOTIFICATIONS);
      finalStatus = status;
    }
    if (finalStatus !== 'granted') {
      return null;
    }
    const tokenData = await Notifications.getExpoPushTokenAsync();
    const token = tokenData.data;
    await AsyncStorage.setItem('expoPushToken', token);
    // send to backend if logged in
    const jwt = await AsyncStorage.getItem('token');
    if (jwt) {
      await fetch('http://localhost:4000/users/me/push-token', { method: 'POST', headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + jwt }, body: JSON.stringify({ token }) });
    }
    return token;
  } catch (e) {
    console.error('Push register error', e);
    return null;
  }
}
