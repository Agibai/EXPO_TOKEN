import React, { useEffect } from 'react';
import * as Notifications from 'expo-notifications';
import Constants from 'expo-constants';
import { Platform } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import AuthRequest from './screens/AuthRequest';
import { registerForPushNotificationsAsync } from './PushRegister';
import AuthVerify from './screens/AuthVerify';
import SearchScreen from './screens/SearchScreen';
import TripScreen from './screens/TripScreen';
import SeatPicker from './screens/SeatPicker';
import ChatScreen from './screens/ChatScreen';
import KaspiPayment from './screens/KaspiPayment';

const Stack = createNativeStackNavigator();

export default function App() {
React.useEffect(()=>{
  (async()=>{ await registerForPushNotificationsAsync(); })();
},[]);

  useEffect(() => {
    async function registerPush() {
      if (!Constants.isDevice) return;
      const { status: existingStatus } = await Notifications.getPermissionsAsync();
      let finalStatus = existingStatus;
      if (existingStatus !== 'granted') {
        const { status } = await Notifications.requestPermissionsAsync();
        finalStatus = status;
      }
      if (finalStatus !== 'granted') return;
      const token = (await Notifications.getExpoPushTokenAsync()).data;
      await AsyncStorage.setItem('pushToken', token);
      const jwt = await AsyncStorage.getItem('token');
      if (jwt) {
        await fetch('http://localhost:4000/users/push-token', { method: 'POST', headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + jwt }, body: JSON.stringify({ token }) });
      }
    }
    registerPush();
  }, []);

  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="AuthRequest">
        <Stack.Screen name="AuthRequest" component={AuthRequest} options={{ title: 'Вход — YRGYZ' }} />
        <Stack.Screen name="AuthVerify" component={AuthVerify} options={{ title: 'Подтверждение кода' }} />
        <Stack.Screen name="Search" component={SearchScreen} options={{ title: 'YRGYZ — Поиск' }} />
        <Stack.Screen name="Trip" component={TripScreen} options={{ title: 'Детали поездки' }} />
              <Stack.Screen name="SeatPicker" component={SeatPicker} options={{ title: 'Выбор мест' }} />
              <Stack.Screen name="Chat" component={ChatScreen} options={{ title: 'Чат' }} />
              <Stack.Screen name="KaspiPayment" component={KaspiPayment} options={{ title: 'Оплата Kaspi' }} />
        </Stack.Navigator>
    </NavigationContainer>
  );
}
