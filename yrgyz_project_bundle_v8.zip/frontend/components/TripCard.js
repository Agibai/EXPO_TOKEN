import React from 'react';
import { TouchableOpacity, Text } from 'react-native';

export default function TripCard({ trip, onPress }) {
  return (
    <TouchableOpacity onPress={onPress} style={{ borderWidth: 1, padding: 12, borderRadius: 8, marginBottom: 10 }}>
      <Text style={{ fontSize: 16, fontWeight: '600' }}>{trip.brand} {trip.model} — {trip.year}</Text>
      <Text>Водитель: {trip.driver}</Text>
      <Text>Мест: {trip.seats} • Цена за место: {trip.price_per_seat} ₸</Text>
      <Text>Кондиционер: {trip.ac ? 'Да' : 'Нет'} • Багажник: {trip.trunk}</Text>
    </TouchableOpacity>
  );
}
