import React, { useEffect, useState } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { View, Text, TouchableOpacity, FlatList, Button, Alert } from 'react-native';

export default function SeatPicker({ route, navigation }){
  const { tripId, trip } = route.params;
  const [seats, setSeats] = useState(trip?.seatsJson || []);
  const [selected, setSelected] = useState([]);

  const [phone, setPhone] = useState(null);
useEffect(()=>{
  (async()=>{
    const token = await AsyncStorage.getItem('token');
    if (token){
      const resp = await fetch('http://localhost:4000/auth/me',{headers:{Authorization:'Bearer '+token}});
      if(resp.ok){
        const data = await resp.json();
        setPhone(data.phone);
      }
    }
  })();
},[]);

useEffect(()=>{
    // if trip not provided, fetch it
    if (!trip) {
      fetch(`http://localhost:4000/trips/${tripId}`).then(r=>r.json()).then(data=>setSeats(data.seatsJson || []));
    }
  },[]);

  const toggle = (s) => {
    if (selected.includes(s)) setSelected(selected.filter(x=>x!==s));
    else setSelected([...selected, s]);
  };

  const [payLoading, setPayLoading] = useState(false);

  const onConfirm = async (paymentType='cash') => {
    if (selected.length === 0) return Alert.alert('Выберите хотя бы одно место');
    // For MVP we ask for phone in prompt - simpler: use prompt? Not available. We'll assume passengerPhone will be entered in next step via simple prompt simulation.
    // For now, ask for confirmation and send booking with dummy phone (developer should replace with real auth user phone)
    const passengerPhone = phone;
    setPayLoading(true);
    const token = await AsyncStorage.getItem('token');
    const headers = { 'Content-Type': 'application/json' };
    if (token) headers['Authorization'] = 'Bearer ' + token;
    const resp = await fetch(`http://localhost:4000/trips/${tripId}/book`, { method: 'POST', headers, body: JSON.stringify({ passengerPhone, passengerName: 'Guest', seatsBooked: selected.length, seatNumbers: selected, paymentType }) });
    const data = await resp.json();
    setPayLoading(false);
    if (resp.ok) {
      if (paymentType === 'kaspi' && data.kaspiQrLink) {
        navigation.navigate('KaspiPayment', { bookingId: data.bookingId, kaspiQrLink: data.kaspiQrLink });
      } else {
        Alert.alert('Успех', 'Забронировано: ' + selected.join(', '));
        navigation.navigate('Search');
      }
    } else Alert.alert('Ошибка', data.error || 'Не удалось забронировать');
  };

  // render seats as grid
  const rows = [];
  const perRow = 4;
  for (let i=0;i<Math.ceil(seats.length/perRow);i++){
    rows.push(seats.slice(i*perRow, i*perRow+perRow));
  }

  return (
    <View style={{ padding: 12 }}>
      <Text style={{ fontSize: 16, fontWeight: '600', marginBottom: 8 }}>Выберите места</Text>
      {rows.map((row, idx) => (
        <View key={idx} style={{ flexDirection: 'row', marginBottom: 8 }}>
          {row.map(s => (
            <TouchableOpacity key={s} onPress={()=>toggle(s)} style={{ padding:12, borderWidth:1, borderRadius:6, marginRight:8, backgroundColor: selected.includes(s) ? '#ddd' : '#fff' }}>
              <Text>{s}</Text>
            </TouchableOpacity>
          ))}
        </View>
      ))}
      <View style={{ flexDirection: 'row', marginTop: 12 }}>
        <View style={{ flex: 1, marginRight: 6 }}><Button title={'Наличные (' + selected.length + ')'} onPress={()=>onConfirm('cash')} disabled={payLoading} /></View>
        <View style={{ flex: 1, marginLeft: 6 }}><Button title={'Kaspi QR (' + selected.length + ')'} onPress={()=>onConfirm('kaspi')} disabled={payLoading} /></View>
      </View>
    </View>
  );
}
