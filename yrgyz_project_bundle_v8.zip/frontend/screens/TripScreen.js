import React from 'react';
import { View, Text, Button, Alert } from 'react-native';

export default function TripScreen({ route, navigation }){
  const { trip } = route.params;

  const onBook = () => { navigation.navigate('SeatPicker', { tripId: trip.id, trip }); };
    Alert.alert(
      'Подтвердить бронирование',
      `Оплата: наличными при посадке. Если хочешь оплатить через Kaspi — отсканируй QR в следующем экране.\nЦена за место: ${trip.price_per_seat} ₸`,
      [
        { text: 'Отмена', style: 'cancel' },
        { text: 'Подтвердить (наличные)', onPress: () => Alert.alert('Забронировано', 'Пассажир подтвердил бронь, водитель будет уведомлён.') },
        { text: 'Оплата через Kaspi', onPress: () => Alert.alert('Kaspi', 'Переадресация/показ QR-кода (интеграция позже)') }
      ]
    );
  }

  return (
    <View style={{ padding: 12 }}>
      <Text style={{ fontSize: 18, fontWeight: '600' }}>{trip.brand} {trip.model}</Text>
      <Text>Водитель: {trip.driver}</Text>
      <Text>Цена за место: {trip.price_per_seat} ₸</Text>
      <Button title="Выбрать места" onPress={onBook} />
    </View>
  );
}
