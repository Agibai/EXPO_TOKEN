import React, { useEffect, useState } from 'react';
import { View, Text, TextInput, Button, FlatList } from 'react-native';
import io from 'socket.io-client';

const socket = io('http://localhost:4000');

export default function ChatScreen({ route }){
  const { room } = route.params;
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState('');

  useEffect(()=>{
    socket.emit('joinRoom', room);
    socket.on('message', (msg)=>{
      setMessages(prev=>[...prev, msg]);
    });
    return ()=>{ socket.off('message'); };
  },[]);

  const send = () => {
    const msg = { room, text: input, sender: 'me', ts: Date.now() };
    socket.emit('message', msg);
    setMessages(prev=>[...prev, msg]);
    setInput('');
  };

  return (
    <View style={{ flex:1, padding:12 }}>
      <FlatList
        data={messages}
        keyExtractor={(item,idx)=>idx.toString()}
        renderItem={({item})=>(<Text>{item.sender}: {item.text}</Text>)}
      />
      <TextInput value={input} onChangeText={setInput} style={{borderWidth:1, padding:8, marginBottom:8}} />
      <Button title="Send" onPress={send} />
    </View>
  );
}
