import React, { useState } from 'react';
import { View, TextInput, Button, Alert } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';

export default function AuthVerify({ route, navigation }){
  const { phone } = route.params;
  const [code, setCode] = useState('');
  const verify = async () => {
    const resp = await fetch('http://localhost:4000/auth/verify', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ phone, code }) });
    const data = await resp.json();
    if (resp.ok){
      await AsyncStorage.setItem('token', data.token);
      navigation.replace('Search');
    } else Alert.alert('Ошибка', data.error || 'Не удалось войти');
  }
  return (
    <View style={{ padding: 12 }}>
      <TextInput value={code} onChangeText={setCode} placeholder='Код из SMS' style={{ borderWidth:1, padding:8, borderRadius:6 }} />
      <Button title='Подтвердить' onPress={verify} />
    </View>
  );
}
