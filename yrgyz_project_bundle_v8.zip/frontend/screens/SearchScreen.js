import React, { useState } from 'react';
import { View, TextInput, Button, FlatList, SafeAreaView } from 'react-native';
import TripCard from '../components/TripCard';

const MOCK_TRIPS = [
  {
    id: 't1',
    driver: 'Айдар',
    brand: 'Toyota',
    model: 'Hiace',
    year: 2016,
    seats: 8,
    price_per_seat: 1200,
    ac: true,
    trunk: 'большой',
  },
  {
    id: 't2',
    driver: 'Гульнар',
    brand: 'Hyundai',
    model: 'H1',
    year: 2018,
    seats: 7,
    price_per_seat: 1000,
    ac: true,
    trunk: 'средний',
  }
];

export default function SearchScreen({ navigation }) {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState(MOCK_TRIPS);

  return (
    <SafeAreaView style={{ flex: 1, padding: 12 }}>
      <TextInput
        placeholder="Откуда — Куда, например: Актобе — Атырау"
        value={query}
        onChangeText={setQuery}
        style={{ borderWidth: 1, padding: 8, borderRadius: 6, marginBottom: 10 }}
      />
      <Button title="Найти" onPress={() => {/* здесь подключение поиска */}} />

      <FlatList
        data={results}
        keyExtractor={item => item.id}
        renderItem={({ item }) => (
          <TripCard trip={item} onPress={() => navigation.navigate('Trip', { trip: item })} />
        )}
      />
    </SafeAreaView>
  );
}
