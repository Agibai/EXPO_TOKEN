import React, { useEffect, useState } from 'react';
import { View, Text, Button, Image, Alert } from 'react-native';

export default function KaspiPayment({ route, navigation }){
  const { bookingId, kaspiQrLink } = route.params;
  const [status, setStatus] = useState('pending');

  useEffect(()=>{
    let mounted = true;
    const check = async () => {
      try {
        const resp = await fetch(`http://localhost:4000/payments/${bookingId}/status`);
        const data = await resp.json();
        if (mounted) setStatus(data.paymentStatus);
      } catch(e){ console.error(e); }
    };
    check();
    const iv = setInterval(check, 5000);
    return ()=>{ mounted=false; clearInterval(iv); };
  },[]);

  return (
    <View style={{ padding: 12 }}>
      <Text style={{ fontSize: 16, fontWeight: '600' }}>Оплата через Kaspi</Text>
      <Text>Booking ID: {bookingId}</Text>
      <Text>Статус: {status}</Text>
      <Text style={{ marginVertical: 8 }}>Отсканируй QR в своём Kaspi.kz приложении или перейди по ссылке:</Text>
      <Text selectable>{kaspiQrLink}</Text>
      <Button title="Проверить ещё раз" onPress={async ()=>{ const resp = await fetch(`http://localhost:4000/payments/${bookingId}/status`); const data = await resp.json(); setStatus(data.paymentStatus); if(data.paymentStatus==='paid') Alert.alert('Оплата подтверждена'); }} />
      <Button title="Я оплатил — подтвердить (dev)" onPress={async ()=>{ await fetch(`http://localhost:4000/payments/${bookingId}/confirm`, { method: 'POST' }); Alert.alert('Оплата подтверждена (симуляция)'); }} />
    </View>
  );
}
