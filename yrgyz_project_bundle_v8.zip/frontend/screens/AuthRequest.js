import React, { useState } from 'react';
import { View, TextInput, Button, Alert } from 'react-native';

export default function AuthRequest({ navigation }){
  const [phone, setPhone] = useState('');

  const send = async () => {
    const resp = await fetch('http://localhost:4000/auth/request_sms', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ phone }) });
    const data = await resp.json();
    if (resp.ok) { Alert.alert('Код отправлен'); navigation.navigate('AuthVerify', { phone }); }
    else Alert.alert('Ошибка', data.error || 'Не удалось отправить код');
  }
  return (
    <View style={{ padding: 12 }}>
      <TextInput value={phone} onChangeText={setPhone} placeholder='+7700...' style={{ borderWidth:1, padding:8, borderRadius:6 }} />
      <Button title='Отправить код' onPress={send} />
    </View>
  );
}
