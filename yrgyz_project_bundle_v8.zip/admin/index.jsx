import React, { useEffect, useState } from 'react';
import { createRoot } from 'react-dom/client';

function Admin(){
  const [users, setUsers] = useState([]);
  const [trips, setTrips] = useState([]);
  const [bookings, setBookings] = useState([]);

  useEffect(()=>{ 
    fetch('/admin/users').then(r=>r.json()).then(setUsers); 
    fetch('/admin/trips').then(r=>r.json()).then(setTrips); 
    fetch('/admin/bookings').then(r=>r.json()).then(setBookings); 
  },[]);

  const block = async (id) => { await fetch(`/admin/users/${id}/block`, { method: 'POST' }); setUsers(users.map(u => u.id===id?{...u, role:'blocked'}:u)); };
  const cancelTrip = async (id) => { await fetch(`/admin/trips/${id}/cancel`, { method: 'POST' }); setTrips(trips.map(t => t.id===id?{...t, status:'cancelled'}:t)); };
  const cancelBooking = async (id) => { await fetch(`/admin/bookings/${id}/cancel`, { method: 'POST' }); setBookings(bookings.map(b => b.id===id?{...b, status:'cancelled'}:b)); };

  return (
    <div style={{ fontFamily: 'sans-serif', padding: 20 }}>
      <h1>YRGYZ Admin</h1>
      <h2>Пользователи</h2>
      <ul>{users.map(u => <li key={u.id}>{u.phone} — {u.name || '-'} — {u.role} <button onClick={()=>block(u.id)}>Block</button></li>)}</ul>

      <h2>Поездки</h2>
      <ul>{trips.map(t => <li key={t.id}>{t.origin} → {t.destination} ({new Date(t.dateTime).toLocaleString()}) — {t.status} <button onClick={()=>cancelTrip(t.id)}>Cancel</button></li>)}</ul>

      <h2>Бронирования</h2>
      <ul>{bookings.map(b => <li key={b.id}>{b.passenger?.phone || b.passengerId} — trip:{b.tripId} — {b.status} <button onClick={()=>cancelBooking(b.id)}>Cancel</button></li>)}</ul>
    </div>
  );
}

const root = createRoot(document.getElementById('root'));
root.render(<Admin />);
