const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

async function main(){
  // create admin user
  const admin = await prisma.user.upsert({
    where: { phone: '+77009990000' },
    update: {},
    create: { name: 'Admin', phone: '+77009990000', role: 'admin' }
  });
  const driver = await prisma.user.upsert({
    where: { phone: '+77001234567' },
    update: {},
    create: { name: 'Айдар', phone: '+77001234567', role: 'driver' }
  });
  const vehicle = await prisma.vehicle.upsert({
    where: { id: 1 },
    update: {},
    create: { driverId: driver.id, brand: 'Toyota', model: 'Hiace', year: 2016, seats: 8, ac: true, trunkSize: 'большой' }
  });
  await prisma.trip.upsert({
    // seatsJson: numbered seats for selection
    // example seats: ['1','2',...]

    where: { id: 1 },
    update: {},
    create: { vehicleId: vehicle.id, driverId: driver.id, origin: 'Актобе', seatsJson: ['1','2','3','4','5','6','7','8'], destination: 'Атырау', dateTime: new Date(Date.now() + 24*3600*1000), pricePerSeat: 1200, totalSeats: 8, availableSeats: 8 }
  });
  console.log('Seed done');
}

main().catch(e => { console.error(e); process.exit(1); }).finally(async () => { await prisma.$disconnect(); });
