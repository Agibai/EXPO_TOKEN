require('dotenv').config();
const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

// Push notifications
const { Expo } = require('expo-server-sdk');
const expo = new Expo();

const { createServer } = require('http');
const { Server } = require('socket.io');
const httpServer = createServer(app);
const io = new Server(httpServer, { cors: { origin: '*' } });

io.on('connection', (socket) => {
  console.log('socket connected', socket.id);
  socket.on('joinRoom', (room)=>{ socket.join(room); });
  socket.on('message', (msg)=>{ io.to(msg.room).emit('message', msg); });
});

const jwt = require('jsonwebtoken');
const JWT_SECRET = process.env.JWT_SECRET || 'devsecret';
let twilioClient = null;
if (process.env.TWILIO_SID && process.env.TWILIO_TOKEN) {
  const twilio = require('twilio');
  twilioClient = twilio(process.env.TWILIO_SID, process.env.TWILIO_TOKEN);
}

const app = express();
app.use(cors());
app.use(bodyParser.json());

function genCode(){ return Math.floor(100000 + Math.random()*900000).toString(); }

// Auth helpers
function authenticateJWT(req, res, next) {
  const auth = req.headers.authorization;
  if (!auth) return res.status(401).json({ error: 'No auth token' });
  const parts = auth.split(' ');
  if (parts.length !== 2) return res.status(401).json({ error: 'Invalid auth header' });
  const token = parts[1];
  try {
    const payload = jwt.verify(token, JWT_SECRET);
    req.auth = payload;
    return next();
  } catch (e) {
    return res.status(401).json({ error: 'Invalid token' });
  }
}

async function loadUserMiddleware(req, res, next) {
  if (!req.auth) return res.status(401).json({ error: 'No auth payload' });
  const user = await prisma.user.findUnique({ where: { id: req.auth.userId } });
  if (!user) return res.status(401).json({ error: 'User not found' });
  req.user = user;
  next();
}

function isAdmin(req, res, next) {
  if (!req.user) return res.status(401).json({ error: 'No user' });
  if (req.user.role !== 'admin') return res.status(403).json({ error: 'Admin only' });
  next();
}

// ----------------- Public endpoints -----------------
// GET /trips - простой фильтр по origin/destination/date
app.get('/trips', async (req, res) => {
  const { origin, destination, date } = req.query;
  const where = {};
  if (origin) where.origin = { contains: origin, mode: 'insensitive' };
  if (destination) where.destination = { contains: destination, mode: 'insensitive' };
  if (date) {
    const dayStart = new Date(date);
    const dayEnd = new Date(date);
    dayEnd.setDate(dayEnd.getDate() + 1);
    where.dateTime = { gte: dayStart, lt: dayEnd };
  }
  const trips = await prisma.trip.findMany({ where, include: { vehicle: true } });
  res.json(trips);
});

// GET /trips/:id - детали поездки
app.get('/trips/:id', async (req, res) => {
  const id = parseInt(req.params.id);
  const trip = await prisma.trip.findUnique({ where: { id }, include: { vehicle: true } });
  if (!trip) return res.status(404).json({ error: 'trip not found' });
  res.json(trip);
});

// POST /trips/:id/book - бронирование места (transactional)
app.post('/trips/:id/book', async (req, res) => {
  const tripId = parseInt(req.params.id);
  const { passengerPhone, passengerName, seatsBooked, paymentType, seatNumbers } = req.body;
  if (!passengerPhone || !seatsBooked) return res.status(400).json({ error: 'phone and seatsBooked required' });
  // seatNumbers: array of strings e.g. ['1','2'] of length seatsBooked
  if (!seatNumbers || !Array.isArray(seatNumbers) || seatNumbers.length !== seatsBooked) return res.status(400).json({ error: 'seatNumbers array required and must match seatsBooked' });

  try {
    const result = await prisma.$transaction(async (prismaTx) => {
      let user = await prismaTx.user.findUnique({ where: { phone: passengerPhone } });
      if (!user) {
        user = await prismaTx.user.create({ data: { phone: passengerPhone, name: passengerName || null } });
      }

      const trip = await prismaTx.trip.findUnique({ where: { id: tripId } });
      if (!trip) throw new Error('trip not found');
      if (trip.availableSeats < seatsBooked) throw new Error('not enough seats');
      const seats = trip.seatsJson || [];
      // check requested seats are available
      for (const s of seatNumbers) {
        if (!seats.includes(s)) throw new Error('seat ' + s + ' not available');
      }
      // remove seats from array
      const newSeats = seats.filter(s => !seatNumbers.includes(s));

      const booking = await prismaTx.booking.create({
        data: {
          tripId,
          passengerId: user.id,
          seatsBooked,
          paymentType: paymentType || 'cash',
          seatNumbers
        }
      });

      await prismaTx.trip.update({ where: { id: tripId }, data: { availableSeats: trip.availableSeats - seatsBooked, seatsJson: newSeats } });

      return { booking, user };
    });

    console.log('New booking:', result.booking.id, 'passenger:', result.user.phone, 'seats:', req.body.seatNumbers);

    res.json({ bookingId: result.booking.id, message: 'Бронирование создано. Платёж: ' + ((req.body.paymentType === 'kaspi') ? 'через Kaspi' : 'наличными при посадке') });
  } catch (err) {
    console.error(err);
    return res.status(400).json({ error: err.message || 'booking failed' });
  }
});

  // after transaction, if kaspi requested, generate QR (mock) and update booking
  if (req.body.paymentType === 'kaspi'){
    // mock QR link - in prod generate real Kaspi QR or deeplink
    const mockLink = `https://kaspi.qr.mock/booking/${result.booking.id}`;
    await prisma.booking.update({ where: { id: result.booking.id }, data: { kaspiQrLink: mockLink, paymentStatus: 'pending' } });
    return res.json({ bookingId: result.booking.id, kaspiQrLink: mockLink, message: 'Сгенерирован Kaspi QR. Оплатите, затем подтвердите платёж.' });
  }
  return res.json({ bookingId: result.booking.id, message: 'Бронирование создано. Платёж: наличными при посадке' });
});


// ----------------- Auth endpoints -----------------
app.post('/auth/request_sms', async (req, res) => {
  const { phone } = req.body;
  if (!phone) return res.status(400).json({ error: 'phone required' });
  const code = genCode();
  const expiresAt = new Date(Date.now() + 5*60*1000);
  await prisma.oneTimeCode.create({ data: { phone, code, expiresAt } });

  if (twilioClient && process.env.TWILIO_FROM) {
    try {
      await twilioClient.messages.create({ body: `YRGYZ код: ${code}`, from: process.env.TWILIO_FROM, to: phone });
      return res.json({ message: 'Код отправлен через Twilio' });
    } catch (e) {
      console.error('Twilio error', e);
      // fall-through to logging mode
    }
  }

  console.log('OTP for', phone, code);
  res.json({ message: 'Код отправлен (в дев-режиме он также логируется в консоль).' });
});

app.post('/auth/verify', async (req, res) => {
  const { phone, code } = req.body;
  if (!phone || !code) return res.status(400).json({ error: 'phone and code required' });
  const record = await prisma.oneTimeCode.findFirst({ where: { phone, code, used: false }, orderBy: { expiresAt: 'desc' } });
  if (!record) return res.status(400).json({ error: 'invalid code' });
  if (new Date(record.expiresAt) < new Date()) return res.status(400).json({ error: 'code expired' });
  await prisma.oneTimeCode.update({ where: { id: record.id }, data: { used: true } });
  let user = await prisma.user.findUnique({ where: { phone } });
  if (!user) user = await prisma.user.create({ data: { phone } });
  const token = jwt.sign({ userId: user.id, role: user.role }, JWT_SECRET, { expiresIn: '30d' });
  res.json({ token, user: { id: user.id, phone: user.phone, name: user.name, role: user.role } });
});

// GET /auth/me
app.get('/auth/me', authenticateJWT, loadUserMiddleware, async (req, res) => {
  res.json({ user: req.user });
});

// ----------------- Admin endpoints (protected) -----------------
app.get('/admin/users', authenticateJWT, loadUserMiddleware, isAdmin, async (req, res) => {
  const users = await prisma.user.findMany({ take: 200 });
  res.json(users);
});

app.post('/admin/users/:id/block', authenticateJWT, loadUserMiddleware, isAdmin, async (req, res) => {
  const id = parseInt(req.params.id);
  const user = await prisma.user.update({ where: { id }, data: { role: 'blocked' } });
  res.json({ ok: true, user });
});

app.get('/admin/trips', authenticateJWT, loadUserMiddleware, isAdmin, async (req, res) => {
  const trips = await prisma.trip.findMany({ include: { vehicle: true }, take: 200 });
  res.json(trips);
});

app.post('/admin/trips/:id/cancel', authenticateJWT, loadUserMiddleware, isAdmin, async (req, res) => {
  const id = parseInt(req.params.id);
  const trip = await prisma.trip.update({ where: { id }, data: { status: 'cancelled' } });
  res.json({ ok: true, trip });
});

app.get('/admin/bookings', authenticateJWT, loadUserMiddleware, isAdmin, async (req, res) => {
  const bookings = await prisma.booking.findMany({ include: { trip: true, passenger: true }, take: 200 });
  res.json(bookings);
});

app.post('/admin/bookings/:id/cancel', authenticateJWT, loadUserMiddleware, isAdmin, async (req, res) => {
  const id = parseInt(req.params.id);
  const booking = await prisma.booking.update({ where: { id }, data: { status: 'cancelled' } });
  const trip = await prisma.trip.findUnique({ where: { id: booking.tripId } });
  await prisma.trip.update({ where: { id: trip.id }, data: { availableSeats: trip.availableSeats + booking.seatsBooked } });
  res.json({ ok: true, booking });
});



// ----------------- Kaspi payment simulation -----------------
// In production, integrate with Kaspi API and implement webhook verification.

app.get('/payments/:bookingId/status', async (req, res) => {
  const bookingId = parseInt(req.params.bookingId);
  const booking = await prisma.booking.findUnique({ where: { id: bookingId } });
  if (!booking) return res.status(404).json({ error: 'booking not found' });
  res.json({ paymentStatus: booking.paymentStatus || 'pending' });
});

// Admin/test endpoint to confirm payment (simulate Kaspi webhook)


// Save expo push token for user
app.post('/users/push-token', async (req, res) => {
  const { token } = req.body;
  if (!req.user) return res.status(401).json({ error: 'unauthorized' });
  await prisma.user.update({ where: { id: req.user.id }, data: { expoPushToken: token } });
  res.json({ ok: true });
});
app.post('/payments/:bookingId/confirm', async (req, res) => {
  const bookingId = parseInt(req.params.bookingId);
  const booking = await prisma.booking.update({ where: { id: bookingId }, data: { paymentStatus: 'paid' } });

  // notify driver and passenger - placeholder: console.log
  console.log('Payment confirmed for booking', bookingId);

  // Send push notifications
  try {
    const bookingFull = await prisma.booking.findUnique({ where: { id: bookingId }, include: { trip: { include: { driver: true } }, passenger: true } });
    const messages = [];
    if (bookingFull.passenger.expoPushToken) messages.push({ to: bookingFull.passenger.expoPushToken, sound: 'default', body: '✅ Оплата прошла успешно' });
    if (bookingFull.trip.driver.expoPushToken) messages.push({ to: bookingFull.trip.driver.expoPushToken, sound: 'default', body: '💰 Пассажир оплатил бронь' });
    if (messages.length) await expo.sendPushNotificationsAsync(messages);
  } catch(e){ console.error('Push send error', e); }
  res.json({ ok: true });
});
const PORT = process.env.PORT || 4000;
app.listen(PORT, () => console.log(`Server listening on ${PORT}`));
