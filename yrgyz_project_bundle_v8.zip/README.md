# YRGYZ — Project bundle

В этом архиве:
- frontend/ — стартовый Expo проект (App.js, screens, components)
- backend/ — Express + Prisma skeleton (server.js, prisma_schema.prisma, seed.js, .env.example)
- admin/ — простой скелет админ-панели (React)
- openapi.yaml — базовая OpenAPI спецификация

## Как запустить фронтенд (локально)
1. Установи Node.js и Expo CLI.
2. Перейди в frontend/: `cd frontend`
3. `npm install`
4. `expo start`

## Как запустить бэкенд (локально)
1. Установи PostgreSQL.
2. Перейди в backend/: `cd backend`
3. `npm install`
4. Скопируй .env.example -> .env и заполни DATABASE_URL
5. `npx prisma migrate dev --name init`
6. `node seed.js`
7. `npm run dev`

## Admin
Простой скелет. Можно доработать на Create React App/Vite.

## OpenAPI
openapi.yaml содержит 2 основных эндпойнта для MVP.



## Important env vars
- `DATABASE_URL` — Postgres connection string
- `JWT_SECRET` — secret for signing JWT tokens (set to a strong value in prod)
- `TWILIO_SID`, `TWILIO_TOKEN`, `TWILIO_FROM` — optional, for sending SMS via Twilio. If not set, OTPs are logged to the server console (dev mode).

## Next recommended steps (pick one):
1. Implement Socket.IO chat (real-time) and integrate with mobile client.
2. Add Kaspi QR generation / payments flow (server-side QR generator or deep-link integration).
3. Add push notifications (FCM) to notify drivers about new bookings.
4. Design UI in Figma and iterate on UX for seat selection.
5. Prepare Docker Compose for local dev (Postgres + backend).



## Push Notifications & CI/CD
- При старте приложение регистрирует Expo push-токен и отправляет на сервер.
- Сервер хранит токен и при подтверждении оплаты отправляет пуши водителю и пассажиру.

### CI/CD (Expo EAS)
- Для сборки APK: `eas build -p android --profile production`
- Для сборки iOS (.ipa): `eas build -p ios --profile production`
- Требуется аккаунт Expo и Apple Developer/Google Play.


## Push notifications and EAS Build

- The backend uses `expo-server-sdk` to send push notifications. Run `npm install` in backend to install deps.
- On the client, use Expo `expo-notifications` to obtain push token and POST it to `/users/me/push-token` (endpoint exists and requires JWT).
- To build a standalone APK or IPA, use Expo EAS:
  1. Install `eas-cli` and login: `npm install -g eas-cli` and `eas login`.
  2. Configure `eas.json` (provided) and run `eas build --platform android` or `eas build --platform ios`.



## Docker Compose (prod-demo) — быстрый запуск на VPS
1. Скопируй проект на VPS в каталог `/home/<user>/yrgyz`.
2. Установи Docker и Docker Compose.
3. Создай `.env` если нужно и отредактируй `docker-compose.yml` (пароли, секреты).
4. Запусти: `docker compose up -d` — это создаст Postgres и backend. Backend выполнит миграции (`npx prisma migrate deploy`) и запустится.
5. Просмотри логи: `docker compose logs -f backend`.

## GitHub Actions — CI/CD
- Workflow `.github/workflows/deploy.yml` строит Docker image для backend и пушит в Docker Hub, затем по SSH перезапускает compose на VPS.
- Для работы добавь секреты в GitHub repo: `DOCKERHUB_USERNAME`, `DOCKERHUB_TOKEN`, `VPS_HOST`, `VPS_USER`, `VPS_SSH_KEY`, `EXPO_TOKEN`.

## EAS (Expo) — сборки мобильного клиента
- В workflow используется `eas build` (нужен `EXPO_TOKEN` в secrets).
- Перед использованием настрой проект Expo (eas build:configure) и добавь необходимые секреты.

