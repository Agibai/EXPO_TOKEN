#!/bin/sh
# Usage: run on VPS to pull latest image and restart compose
cd /home/$(whoami)/yrgyz || exit 1
git pull origin main
docker compose pull
docker compose up -d --build
